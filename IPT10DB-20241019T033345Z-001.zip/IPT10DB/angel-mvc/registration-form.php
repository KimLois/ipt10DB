<form method="POST" action="/register">
    <label>Username: <input type="text" name="username" required></label><br>
    <label>Email: <input type="email" name="email" required></label><br>
    <label>First Name: <input type="text" name="first_name"></label><br>
    <label>Last Name: <input type="text" name="last_name"></label><br>
    <label>Password: <input type="password" name="password" required></label><br>
    <label>Confirm Password: <input type="password" name="password_confirmation" required></label><br>
    <input type="submit" value="Register">
</form>
<?php if (isset($errors)) foreach ($errors as $error) echo "<p>$error</p>"; ?>