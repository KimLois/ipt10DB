<?php
namespace App\Controllers;

use App\Models\Users;

class LoginController {
    public function showForm() {
        include 'views/login-form.php';
    }

    public function login() {
        if (!isset($_SESSION['attempts'])) $_SESSION['attempts'] = 0;

        $userModel = new Users();
        $success = $userModel->login($_POST['username'], $_POST['password']);

        if ($success) {
            header("Location: /welcome");
            exit();
        } else {
            $_SESSION['attempts']++;
            if ($_SESSION['attempts'] >= 3) {
                echo "<p>Login disabled after 3 attempts. Please try again later.</p>";
            } else {
                echo "<p>Invalid username or password.</p>";
                include 'views/login-form.php';
            }
        }
    }

    public function logout() {
        session_destroy();
        header("Location: /login-form");
    }
}
?>