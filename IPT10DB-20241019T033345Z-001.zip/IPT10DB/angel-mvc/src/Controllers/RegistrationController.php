<?php
namespace App\Controllers;

use App\Models\Users;

class RegistrationController {
    public function showForm() {
        include 'views/registration-form.php';
    }

    public function register() {
        $userModel = new Users();
        $errors = $userModel->register($_POST);

        if (is_array($errors)) {
            // Display errors on the form page
            include 'views/registration-form.php';
        } else {
            echo "<p>$errors</p>";
            echo "<a href='/login-form'>Go to Login</a>";
        }
    }
}
?>