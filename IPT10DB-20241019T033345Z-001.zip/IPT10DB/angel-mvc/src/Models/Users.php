<?php
namespace App\Models;

use App\DatabaseConnection;

class Users {
    private $ipt10;

    public function __construct() {
        $this->ipt10 = (new DatabaseConnection())->getConnection();
    }

    public function register($data) {
        // Validate password requirements
        $errors = [];
        if (strlen($data['password']) < 8) $errors[] = "Password must be at least 8 characters.";
        if (!preg_match('/[0-9]/', $data['password'])) $errors[] = "Password must contain at least one number.";
        if (!preg_match('/[^a-zA-Z0-9]/', $data['password'])) $errors[] = "Password must contain at least one special character.";
        
        if ($errors) return $errors;

        // Hash the password
        $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);

        // Insert user data into database
        $sql = "INSERT INTO users (username, email, first_name, last_name, password) VALUES (:username, :email, :first_name, :last_name, :password)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':username' => $data['username'],
            ':email' => $data['email'],
            ':first_name' => $data['first_name'],
            ':last_name' => $data['last_name'],
            ':password' => $hashedPassword
        ]);

        return "Successful Registration";
    }

    public function login($username, $password) {
        // Check if user exists
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['is_logged_in'] = true;
            $_SESSION['user_id'] = $user['id'];
            return true;
        } else {
            return false;
        }
    }
}
?>
```
